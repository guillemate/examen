var contenedor = document.getElementById("contenedor")
var jugador=0;
var cpu=0;
const jugar=()=> {
    const radios = document.getElementsByName("ppt");
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            jugador = radios[i].value;
        }
    }
    llamarCPU();
}
const llamarCPU=()=>{
    fetch("http://localhost:8001/ppt", {
        "method": "GET"
    }).then(x=>x.text()).then(x=>{
        cpu =x;
        console.log('Respuesta recibida');
        console.log(cpu);
        contenedor.innerHTML=jugada();
        enviarPost(jugada());
    });
}
const enviarPost=(jugada)=>{
    fetch("http://localhost:8001/pptPost", {
        "method": "POST",
        "body": jugada
    })
}
const jugada=()=>{
    if(cpu==jugador){
        return "EMPATE";
    }
    if(cpu==1 && jugador==2){
        return "Gana el jugador";
    }
    if(cpu==2 && jugador==1){
        return "Gana la cpu";
    }
    if(cpu==2 && jugador==3){
        return "Gana el jugador";
    }
    if(cpu==3 && jugador==2){
        return "Gana la cpu";
    }
    if(cpu==3 && jugador==1){
        return "Gana la jugador";
    }
    if(cpu==1 && jugador==3){
        return "Gana el cpu";
    }
}